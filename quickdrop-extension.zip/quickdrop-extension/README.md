# QuickDrop – Instant File Upload Extension

> Capture downloads and instantly drag or upload them to any webpage — no more hunting through your Downloads folder.

---

## How It Works

1. **You download a file** — Chrome's download API detects it automatically
2. **QuickDrop stores it** — file metadata + base64 data saved locally (last 10 files)
3. **Open any page with an upload field** — Gmail, Notion, Slack, etc.
4. **Open the popup** → click Upload or drag the file into the upload area

---

## Installation (Developer Mode)

1. Open Chrome and go to `chrome://extensions`
2. Enable **Developer mode** (toggle in the top-right)
3. Click **Load unpacked**
4. Select the `quickdrop-extension/` folder
5. The QuickDrop icon appears in your toolbar — pin it for easy access

---

## File Structure

```
quickdrop-extension/
├── manifest.json      — Extension config (MV3)
├── background.js      — Service worker: download detection + storage
├── content.js         — Injected into pages: drag-drop + inject file into input
├── popup.html         — Popup UI markup
├── popup.js           — Popup logic: render, upload, delete, drag
├── style.css          — Popup styles
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## File Descriptions

### `manifest.json`
Declares the extension using Manifest V3. Sets permissions (`downloads`, `storage`, `scripting`, `activeTab`), registers the background service worker, popup action, and injects `content.js` into all URLs.

### `background.js`
The service worker (runs in the background):
- Listens to `chrome.downloads.onChanged` for `state === "complete"`
- Fetches the downloaded file via `file://` URL and converts to base64
- Stores up to 10 files in `chrome.storage.local`
- Handles messages from popup and content script

### `content.js`
Injected into every webpage:
- Listens for `QUICKDROP_INJECT` messages from popup
- Converts base64 → `File` object → injects into `<input type="file">`
- Handles drag-over highlighting of file inputs
- Handles drop events from popup drag operations
- Shows toast notifications on success/failure

### `popup.html / popup.js / style.css`
The popup opened when clicking the extension icon:
- Renders file cards with preview (thumbnail for images, SVG icon otherwise)
- Drag-start sets `dataTransfer` with `application/x-quickdrop` + fileId
- Upload button sends `QUICKDROP_INJECT` message to active tab
- Delete button removes a file from storage
- Clear All removes everything
- Listens for `FILES_UPDATED` to refresh when background adds a new file

---

## Testing

### Basic test
1. Go to [https://google.com/images](https://google.com/images), right-click an image → **Save image as…** → save it
2. The extension icon should show the file within ~1 second
3. Go to [https://imgur.com/upload](https://imgur.com/upload)
4. Open the QuickDrop popup
5. Click **Upload** on the image card
6. The image is injected into Imgur's file input — a green toast confirms it

### Drag test
1. Download a PDF (any site)
2. Open [https://www.ilovepdf.com](https://www.ilovepdf.com) (has a large drop zone)
3. Open the QuickDrop popup
4. **Drag** the PDF card from the popup onto the upload area on the page
5. The file is dropped and accepted

### Gmail attachment test
1. Download any file
2. Open [https://mail.google.com](https://mail.google.com), compose a new email
3. Open QuickDrop popup → click **Upload**
4. Gmail's file input is detected and the file is attached

---

## Example Workflow

```
User downloads report.pdf from company portal
         ↓
background.js detects download completion
         ↓
File bytes read as base64, saved to chrome.storage.local
         ↓
User opens Gmail, starts composing email
         ↓
User clicks QuickDrop icon → sees report.pdf card
         ↓
User clicks [↑ Upload]
         ↓
content.js receives QUICKDROP_INJECT message
         ↓
Finds <input type="file"> in Gmail's DOM
         ↓
Creates File object from base64, injects via DataTransfer
         ↓
Gmail sees the file attached ✅
```

---

## Limitations & Notes

- **File reading**: The extension reads files from `file://` URLs. Some system/protected directories may block this.
- **Large files**: Files are stored as base64 in `chrome.storage.local` (max 10 MB per item recommended). Very large files (>50 MB) may be slow.
- **Site restrictions**: Some sites use custom upload widgets (not `<input type="file">`). QuickDrop works with standard HTML file inputs.
- **Drag from popup**: Chrome's popup closes on dragend. The drag works by injecting the content script first, so the file is available on drop even after the popup closes.
- **Permissions**: The extension does not send any data externally. All storage is local.

---

## Permissions Explained

| Permission | Why |
|---|---|
| `downloads` | Detect when files finish downloading |
| `storage` | Save file list in `chrome.storage.local` |
| `scripting` | Re-inject content.js into tabs when needed |
| `activeTab` | Send messages to the current tab |
| `<all_urls>` | Inject content script and upload to any website |
