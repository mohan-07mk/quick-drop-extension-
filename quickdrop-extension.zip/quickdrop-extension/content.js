/**
 * content.js — QuickDrop Content Script
 *
 * Injected into every page. Responsibilities:
 *  • Listen for the custom "quickdrop-inject" event fired by popup.js
 *    (popup → scripting.executeScript → dispatchEvent)
 *  • Receive a dragged file's data and inject it into the best upload
 *    input found on the page
 *  • Highlight valid drop targets when a QuickDrop drag is in progress
 */

(function () {
  "use strict";

  // Avoid double-injection
  if (window.__quickdropLoaded) return;
  window.__quickdropLoaded = true;

  // ─────────────────────────────────────────────
  // Helpers
  // ─────────────────────────────────────────────

  /** Convert a base64 dataURL to a File object */
  function dataUrlToFile(dataUrl, filename, mimeType) {
    const arr = dataUrl.split(",");
    const bstr = atob(arr[1]);
    const u8arr = new Uint8Array(bstr.length);
    for (let i = 0; i < bstr.length; i++) {
      u8arr[i] = bstr.charCodeAt(i);
    }
    return new File([u8arr], filename, { type: mimeType || "application/octet-stream" });
  }

  /** Find the most likely file input on the page */
  function findBestFileInput() {
    // Prioritise visible, enabled inputs
    const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
    const visible = inputs.filter((el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return (
        style.display !== "none" &&
        style.visibility !== "hidden" &&
        style.opacity !== "0" &&
        rect.width >= 0 &&
        rect.height >= 0
      );
    });
    return visible[0] || inputs[0] || null;
  }

  /** Inject a File into a file input and trigger change events */
  function injectFileIntoInput(input, file) {
    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;

      // Dispatch both change and input events so frameworks pick it up
      input.dispatchEvent(new Event("change", { bubbles: true }));
      input.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    } catch (err) {
      console.error("[QuickDrop] Failed to inject file:", err);
      return false;
    }
  }

  /** Show a brief toast overlay on the page */
  function showToast(message, isError = false) {
    // Remove existing toast
    document.getElementById("__quickdrop_toast")?.remove();

    const toast = document.createElement("div");
    toast.id = "__quickdrop_toast";
    toast.textContent = message;
    Object.assign(toast.style, {
      position: "fixed",
      bottom: "24px",
      right: "24px",
      zIndex: "2147483647",
      background: isError ? "#ef4444" : "#10b981",
      color: "#fff",
      padding: "10px 18px",
      borderRadius: "8px",
      fontSize: "14px",
      fontFamily: "system-ui, sans-serif",
      boxShadow: "0 4px 20px rgba(0,0,0,0.25)",
      pointerEvents: "none",
      transition: "opacity 0.3s ease",
      opacity: "1",
    });
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      setTimeout(() => toast.remove(), 300);
    }, 2500);
  }

  // ─────────────────────────────────────────────
  // Message listener: popup asks us to inject
  // ─────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type !== "QUICKDROP_INJECT") return;

    const { fileId } = message;

    // Ask background for the file data
    chrome.runtime.sendMessage(
      { type: "GET_FILE_DATA", fileId },
      (response) => {
        if (!response || !response.file) {
          showToast("⚠️ QuickDrop: File not found in storage.", true);
          sendResponse({ success: false, error: "File not found" });
          return;
        }

        const { file } = response;

        if (!file.dataUrl) {
          showToast("⚠️ QuickDrop: File data unavailable. Try re-downloading.", true);
          sendResponse({ success: false, error: "No data URL" });
          return;
        }

        const fileObj = dataUrlToFile(file.dataUrl, file.name, file.mimeType);
        const input = findBestFileInput();

        if (!input) {
          showToast("⚠️ QuickDrop: No file input found on this page.", true);
          sendResponse({ success: false, error: "No input found" });
          return;
        }

        const ok = injectFileIntoInput(input, fileObj);
        if (ok) {
          showToast(`✅ QuickDrop: "${file.name}" uploaded!`);
          // Scroll the input into view
          input.scrollIntoView({ behavior: "smooth", block: "center" });
          sendResponse({ success: true });
        } else {
          showToast("⚠️ QuickDrop: Upload failed.", true);
          sendResponse({ success: false, error: "Inject failed" });
        }
      }
    );

    return true; // async
  });

  // ─────────────────────────────────────────────
  // Drag-over highlighting
  // When a QuickDrop drag is in progress (popup sets a flag via
  // chrome.storage.session), highlight drop targets.
  // ─────────────────────────────────────────────
  let highlightStyleEl = null;

  function addHighlightStyles() {
    if (highlightStyleEl) return;
    highlightStyleEl = document.createElement("style");
    highlightStyleEl.id = "__quickdrop_styles";
    highlightStyleEl.textContent = `
      .__qd_highlight {
        outline: 3px dashed #10b981 !important;
        outline-offset: 2px !important;
        background: rgba(16,185,129,0.06) !important;
        transition: outline 0.15s ease !important;
      }
    `;
    document.head.appendChild(highlightStyleEl);
  }

  // Listen for dragover to highlight file inputs
  document.addEventListener(
    "dragover",
    (e) => {
      const types = e.dataTransfer?.types || [];
      if (!types.includes("application/x-quickdrop")) return;

      e.preventDefault();
      addHighlightStyles();

      // Highlight any file input currently under cursor
      const el = document.elementFromPoint(e.clientX, e.clientY);
      if (el && el.matches('input[type="file"]')) {
        el.classList.add("__qd_highlight");
      }
    },
    true
  );

  document.addEventListener(
    "dragleave",
    (e) => {
      const el = e.target;
      if (el && el.classList) el.classList.remove("__qd_highlight");
    },
    true
  );

  // ─────────────────────────────────────────────
  // Drop handler: catch files dragged from popup
  // The popup sets dataTransfer text to the fileId.
  // ─────────────────────────────────────────────
  document.addEventListener(
    "drop",
    async (e) => {
      const fileId = e.dataTransfer?.getData("application/x-quickdrop");
      if (!fileId) return; // Not our drag

      e.preventDefault();
      e.stopPropagation();

      // Remove highlights
      document
        .querySelectorAll(".__qd_highlight")
        .forEach((el) => el.classList.remove("__qd_highlight"));

      // Find the drop target — prefer the element under cursor
      let target = e.target;
      if (!target.matches('input[type="file"]')) {
        target = findBestFileInput();
      }

      if (!target) {
        showToast("⚠️ QuickDrop: No file input found on this page.", true);
        return;
      }

      // Get file data from background
      chrome.runtime.sendMessage(
        { type: "GET_FILE_DATA", fileId },
        (response) => {
          if (!response?.file?.dataUrl) {
            showToast("⚠️ QuickDrop: File data unavailable.", true);
            return;
          }
          const { file } = response;
          const fileObj = dataUrlToFile(file.dataUrl, file.name, file.mimeType);
          const ok = injectFileIntoInput(target, fileObj);
          if (ok) {
            showToast(`✅ QuickDrop: "${file.name}" dropped!`);
          } else {
            showToast("⚠️ QuickDrop: Drop failed.", true);
          }
        }
      );
    },
    true
  );
})();
