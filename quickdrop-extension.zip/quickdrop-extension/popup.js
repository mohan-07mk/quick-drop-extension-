/**
 * popup.js — QuickDrop Popup Controller
 *
 * Responsibilities:
 *  • Load stored files from background via chrome.runtime.sendMessage
 *  • Render file cards with preview, metadata, and action buttons
 *  • Handle drag-start so the file can be dropped on any page
 *  • Handle one-click upload (sends QUICKDROP_INJECT to active tab)
 *  • Handle individual file deletion and Clear All
 */

"use strict";

// ─────────────────────────────────────────────
// Icon map: category → SVG path string
// ─────────────────────────────────────────────
const ICONS = {
  image: `<path d="M4 5a2 2 0 012-2h12a2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2V5z" stroke="currentColor" stroke-width="1.6" fill="none"/><circle cx="9" cy="9" r="1.5" fill="currentColor"/><path d="M4 15l4-4 3 3 3-3 5 5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" fill="none"/>`,
  pdf: `<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M14 2v6h6" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M9 13h.5c.8 0 1.5-.7 1.5-1.5S10.3 10 9.5 10H9v6M15 10v6M15 13h-2M13 16h2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none"/>`,
  word: `<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M14 2v6h6" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M8 12l2 6 2-4 2 4 2-6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none"/>`,
  excel: `<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M14 2v6h6" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M8 10l8 8M16 10l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none"/>`,
  powerpoint: `<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M14 2v6h6" stroke="currentColor" stroke-width="1.6" fill="none"/><rect x="8" y="11" width="5" height="7" rx="1" stroke="currentColor" stroke-width="1.5" fill="none"/>`,
  video: `<path d="M15 10l4.5-2.5v9L15 14M3 8h12v8H3z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" fill="none"/>`,
  audio: `<circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M9 9h6v5l-6 1V9z" stroke="currentColor" stroke-width="1.5" fill="none"/><path d="M9 14a2 2 0 104 0 2 2 0 00-4 0z" stroke="currentColor" stroke-width="1.4" fill="none"/>`,
  archive: `<path d="M21 8v13H3V8M23 3H1v5h22V3z" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M12 12v4M10 14h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none"/>`,
  text: `<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M14 2v6h6" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M8 13h8M8 17h5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none"/>`,
  code: `<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M14 2v6h6" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M9 13l-2 2 2 2M15 13l2 2-2 2M12 11l-1 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none"/>`,
  file: `<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M14 2v6h6" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M8 13h8M8 17h5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none"/>`,
};

// ─────────────────────────────────────────────
// Relative time formatter
// ─────────────────────────────────────────────
function timeAgo(timestamp) {
  const diff = Date.now() - timestamp;
  const mins = Math.floor(diff / 60000);
  const hrs = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  if (hrs < 24) return `${hrs}h ago`;
  return `${days}d ago`;
}

// ─────────────────────────────────────────────
// Build SVG icon for a category
// ─────────────────────────────────────────────
function buildIcon(category) {
  const paths = ICONS[category] || ICONS.file;
  return `<svg class="file-icon-svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">${paths}</svg>`;
}

// ─────────────────────────────────────────────
// Render a single file card
// ─────────────────────────────────────────────
function renderCard(file) {
  const card = document.createElement("div");
  card.className = "file-card";
  card.dataset.id = file.id;
  card.draggable = true;

  const isImage = file.category === "image" && file.dataUrl;

  card.innerHTML = `
    <div class="card-preview ${isImage ? "card-preview--img" : "card-preview--icon"} category-${file.category}">
      ${isImage
        ? `<img src="${file.dataUrl}" alt="${file.name}" class="thumb" />`
        : buildIcon(file.category)
      }
    </div>
    <div class="card-body">
      <p class="card-name" title="${file.name}">${file.name}</p>
      <p class="card-meta">
        <span class="badge badge--${file.category}">${file.category.toUpperCase()}</span>
        <span class="meta-size">${file.size}</span>
        <span class="meta-time">${timeAgo(file.timestamp)}</span>
      </p>
    </div>
    <div class="card-actions">
      <button class="btn-upload" data-id="${file.id}" title="Upload to this tab">
        <svg viewBox="0 0 24 24" fill="none"><path d="M12 15V3m0 0l-4 4m4-4l4 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 17v1a3 3 0 003 3h12a3 3 0 003-3v-1" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
        Upload
      </button>
      <button class="btn-delete" data-id="${file.id}" title="Remove file">
        <svg viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
      </button>
    </div>
    <div class="drag-handle" title="Drag to upload field">
      <svg viewBox="0 0 24 24" fill="none"><path d="M9 5h2M9 12h2M9 19h2M13 5h2M13 12h2M13 19h2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
    </div>
  `;

  return card;
}

// ─────────────────────────────────────────────
// Render all file cards
// ─────────────────────────────────────────────
function renderFiles(files) {
  const list = document.getElementById("fileList");
  const empty = document.getElementById("emptyState");
  const count = document.getElementById("fileCount");

  list.innerHTML = "";

  if (!files || files.length === 0) {
    empty.style.display = "flex";
    count.textContent = "0 files";
    return;
  }

  empty.style.display = "none";
  count.textContent = `${files.length} file${files.length !== 1 ? "s" : ""}`;

  files.forEach((file) => {
    const card = renderCard(file);
    list.appendChild(card);
  });
}

// ─────────────────────────────────────────────
// Load files from background
// ─────────────────────────────────────────────
async function loadFiles() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "GET_FILES" }, (res) => {
      resolve(res?.files || []);
    });
  });
}

// ─────────────────────────────────────────────
// Get the current active tab
// ─────────────────────────────────────────────
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// ─────────────────────────────────────────────
// Trigger upload into active tab
// ─────────────────────────────────────────────
async function uploadToTab(fileId) {
  const tab = await getActiveTab();
  if (!tab) {
    alert("No active tab found.");
    return;
  }

  // Ensure content script is injected (in case page loaded before extension)
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"],
    });
  } catch (_) {
    // Already injected — ignore error
  }

  // Send inject message
  chrome.tabs.sendMessage(tab.id, { type: "QUICKDROP_INJECT", fileId }, (res) => {
    if (chrome.runtime.lastError) {
      console.warn("[QuickDrop Popup] Message error:", chrome.runtime.lastError.message);
    }
  });

  // Close popup so user sees the result toast
  window.close();
}

// ─────────────────────────────────────────────
// Delete a single file
// ─────────────────────────────────────────────
async function deleteFile(fileId) {
  await new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "DELETE_FILE", fileId }, resolve);
  });
  const files = await loadFiles();
  renderFiles(files);
}

// ─────────────────────────────────────────────
// Clear all files
// ─────────────────────────────────────────────
async function clearAll() {
  if (!confirm("Remove all stored files?")) return;
  await new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "CLEAR_ALL" }, resolve);
  });
  renderFiles([]);
}

// ─────────────────────────────────────────────
// Event delegation on file list
// ─────────────────────────────────────────────
document.getElementById("fileList").addEventListener("click", (e) => {
  const uploadBtn = e.target.closest(".btn-upload");
  const deleteBtn = e.target.closest(".btn-delete");

  if (uploadBtn) {
    uploadToTab(uploadBtn.dataset.id);
    return;
  }
  if (deleteBtn) {
    deleteFile(deleteBtn.dataset.id);
    return;
  }
});

// ─────────────────────────────────────────────
// Drag start: set the fileId on dataTransfer
// ─────────────────────────────────────────────
document.getElementById("fileList").addEventListener("dragstart", (e) => {
  const card = e.target.closest(".file-card");
  if (!card) return;

  const fileId = card.dataset.id;
  e.dataTransfer.setData("application/x-quickdrop", fileId);
  e.dataTransfer.effectAllowed = "copy";

  // Show ghost image (the card itself)
  e.dataTransfer.setDragImage(card, 20, 20);

  card.classList.add("dragging");

  // Show tip
  document.getElementById("dragTip").classList.remove("hidden");
});

document.getElementById("fileList").addEventListener("dragend", (e) => {
  const card = e.target.closest(".file-card");
  if (card) card.classList.remove("dragging");
  document.getElementById("dragTip").classList.add("hidden");
});

// ─────────────────────────────────────────────
// Clear All button
// ─────────────────────────────────────────────
document.getElementById("clearAllBtn").addEventListener("click", clearAll);

// ─────────────────────────────────────────────
// Listen for background updates while popup is open
// ─────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "FILES_UPDATED") {
    loadFiles().then(renderFiles);
  }
});

// ─────────────────────────────────────────────
// Init
// ─────────────────────────────────────────────
(async () => {
  const files = await loadFiles();
  renderFiles(files);
})();
