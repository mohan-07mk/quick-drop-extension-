/**
 * background.js — QuickDrop Service Worker
 *
 * Responsibilities:
 *  • Listen for completed downloads via chrome.downloads.onChanged
 *  • Fetch the downloaded file as a blob (via fetch) and convert to base64
 *  • Store the last 10 files in chrome.storage.local
 *  • Respond to messages from popup.js and content.js
 */

const MAX_FILES = 10;

// ─────────────────────────────────────────────
// Helper: format bytes into human-readable size
// ─────────────────────────────────────────────
function formatBytes(bytes) {
  if (!bytes || bytes === 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
}

// ─────────────────────────────────────────────
// Helper: derive a MIME-friendly icon label
// ─────────────────────────────────────────────
function getFileCategory(mimeType, filename) {
  if (!mimeType && filename) {
    const ext = filename.split(".").pop().toLowerCase();
    const extMap = {
      jpg: "image", jpeg: "image", png: "image", gif: "image",
      webp: "image", svg: "image", bmp: "image",
      pdf: "pdf",
      doc: "word", docx: "word",
      xls: "excel", xlsx: "excel",
      ppt: "powerpoint", pptx: "powerpoint",
      zip: "archive", rar: "archive", "7z": "archive", tar: "archive", gz: "archive",
      mp4: "video", mov: "video", avi: "video", mkv: "video",
      mp3: "audio", wav: "audio", ogg: "audio",
      txt: "text", csv: "text", md: "text",
      js: "code", ts: "code", html: "code", css: "code", py: "code", json: "code",
    };
    return extMap[ext] || "file";
  }
  if (!mimeType) return "file";
  if (mimeType.startsWith("image/")) return "image";
  if (mimeType === "application/pdf") return "pdf";
  if (mimeType.includes("word")) return "word";
  if (mimeType.includes("excel") || mimeType.includes("spreadsheet")) return "excel";
  if (mimeType.includes("powerpoint") || mimeType.includes("presentation")) return "powerpoint";
  if (mimeType.startsWith("video/")) return "video";
  if (mimeType.startsWith("audio/")) return "audio";
  if (mimeType.startsWith("text/")) return "text";
  if (mimeType.includes("zip") || mimeType.includes("compressed")) return "archive";
  return "file";
}

// ─────────────────────────────────────────────
// Core: read file from disk path → base64
// Chrome gives us a file:// URL we can fetch.
// ─────────────────────────────────────────────
async function readFileAsBase64(fileUrl) {
  try {
    const response = await fetch(fileUrl);
    if (!response.ok) throw new Error(`Fetch failed: ${response.status}`);
    const blob = await response.blob();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result); // data:<mime>;base64,<data>
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch (err) {
    console.warn("[QuickDrop] Could not read file as base64:", err.message);
    return null;
  }
}

// ─────────────────────────────────────────────
// Core: save a new file entry to storage
// ─────────────────────────────────────────────
async function saveFileEntry(downloadItem) {
  const { id, filename, mime, fileSize, url } = downloadItem;

  // Build a file:// URL from the local path
  const fileUrl = `file://${filename.replace(/\\/g, "/")}`;

  // Attempt to read the actual file bytes so we can inject it later
  const dataUrl = await readFileAsBase64(fileUrl);

  const name = filename.split(/[\\/]/).pop(); // just the filename, no path

  const entry = {
    id: `qd_${id}_${Date.now()}`,
    downloadId: id,
    name,
    path: filename,
    fileUrl,
    mimeType: mime || "",
    category: getFileCategory(mime, name),
    size: formatBytes(fileSize),
    sizeBytes: fileSize || 0,
    sourceUrl: url,
    timestamp: Date.now(),
    dataUrl, // null if we couldn't read it (e.g. permissions)
  };

  // Load existing list
  const result = await chrome.storage.local.get("quickdrop_files");
  let files = result.quickdrop_files || [];

  // Prepend new entry and cap at MAX_FILES
  files.unshift(entry);
  if (files.length > MAX_FILES) {
    files = files.slice(0, MAX_FILES);
  }

  await chrome.storage.local.set({ quickdrop_files: files });
  console.log(`[QuickDrop] Saved: ${name}`);

  // Notify any open popup
  chrome.runtime.sendMessage({ type: "FILES_UPDATED" }).catch(() => {});
}

// ─────────────────────────────────────────────
// Listener: chrome.downloads.onChanged
// Fires whenever a download's state changes.
// We wait until state === "complete".
// ─────────────────────────────────────────────
chrome.downloads.onChanged.addListener(async (delta) => {
  // Only act when a download reaches "complete"
  if (!delta.state || delta.state.current !== "complete") return;

  try {
    // Fetch full download info
    const [item] = await chrome.downloads.search({ id: delta.id });
    if (!item) return;

    // Skip very small items (likely tracking pixels etc.)
    if (item.fileSize > 0 && item.fileSize < 100) return;

    await saveFileEntry(item);
  } catch (err) {
    console.error("[QuickDrop] Error handling download:", err);
  }
});

// ─────────────────────────────────────────────
// Message handler — popup & content script
// ─────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "GET_FILES") {
    chrome.storage.local.get("quickdrop_files").then((result) => {
      sendResponse({ files: result.quickdrop_files || [] });
    });
    return true; // keep channel open for async
  }

  if (message.type === "DELETE_FILE") {
    chrome.storage.local.get("quickdrop_files").then(async (result) => {
      const files = (result.quickdrop_files || []).filter(
        (f) => f.id !== message.fileId
      );
      await chrome.storage.local.set({ quickdrop_files: files });
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === "CLEAR_ALL") {
    chrome.storage.local.set({ quickdrop_files: [] }).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === "GET_FILE_DATA") {
    // Content script asks for the dataUrl of a specific file
    chrome.storage.local.get("quickdrop_files").then((result) => {
      const files = result.quickdrop_files || [];
      const file = files.find((f) => f.id === message.fileId);
      sendResponse({ file: file || null });
    });
    return true;
  }
});
